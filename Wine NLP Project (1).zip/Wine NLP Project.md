
# Creating an NLP Neural Network to Predict Price of Wine

## Flatiron School - Cohort 100719PT
## Instructor - James Irving
## By Acusio Bivona

### Questions for/with James
 - WHAT THE FUCK IS A SINGLETON ARRAY


```python
import pandas as pd
df = pd.read_csv("winemag-data-130k-v2.csv")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>country</th>
      <th>description</th>
      <th>designation</th>
      <th>points</th>
      <th>price</th>
      <th>province</th>
      <th>region_1</th>
      <th>region_2</th>
      <th>taster_name</th>
      <th>taster_twitter_handle</th>
      <th>title</th>
      <th>variety</th>
      <th>winery</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>0</td>
      <td>Italy</td>
      <td>Aromas include tropical fruit, broom, brimston...</td>
      <td>Vulkà Bianco</td>
      <td>87</td>
      <td>NaN</td>
      <td>Sicily &amp; Sardinia</td>
      <td>Etna</td>
      <td>NaN</td>
      <td>Kerin O’Keefe</td>
      <td>@kerinokeefe</td>
      <td>Nicosia 2013 Vulkà Bianco  (Etna)</td>
      <td>White Blend</td>
      <td>Nicosia</td>
    </tr>
    <tr>
      <td>1</td>
      <td>1</td>
      <td>Portugal</td>
      <td>This is ripe and fruity, a wine that is smooth...</td>
      <td>Avidagos</td>
      <td>87</td>
      <td>15.0</td>
      <td>Douro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Roger Voss</td>
      <td>@vossroger</td>
      <td>Quinta dos Avidagos 2011 Avidagos Red (Douro)</td>
      <td>Portuguese Red</td>
      <td>Quinta dos Avidagos</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2</td>
      <td>US</td>
      <td>Tart and snappy, the flavors of lime flesh and...</td>
      <td>NaN</td>
      <td>87</td>
      <td>14.0</td>
      <td>Oregon</td>
      <td>Willamette Valley</td>
      <td>Willamette Valley</td>
      <td>Paul Gregutt</td>
      <td>@paulgwine</td>
      <td>Rainstorm 2013 Pinot Gris (Willamette Valley)</td>
      <td>Pinot Gris</td>
      <td>Rainstorm</td>
    </tr>
    <tr>
      <td>3</td>
      <td>3</td>
      <td>US</td>
      <td>Pineapple rind, lemon pith and orange blossom ...</td>
      <td>Reserve Late Harvest</td>
      <td>87</td>
      <td>13.0</td>
      <td>Michigan</td>
      <td>Lake Michigan Shore</td>
      <td>NaN</td>
      <td>Alexander Peartree</td>
      <td>NaN</td>
      <td>St. Julian 2013 Reserve Late Harvest Riesling ...</td>
      <td>Riesling</td>
      <td>St. Julian</td>
    </tr>
    <tr>
      <td>4</td>
      <td>4</td>
      <td>US</td>
      <td>Much like the regular bottling from 2012, this...</td>
      <td>Vintner's Reserve Wild Child Block</td>
      <td>87</td>
      <td>65.0</td>
      <td>Oregon</td>
      <td>Willamette Valley</td>
      <td>Willamette Valley</td>
      <td>Paul Gregutt</td>
      <td>@paulgwine</td>
      <td>Sweet Cheeks 2012 Vintner's Reserve Wild Child...</td>
      <td>Pinot Noir</td>
      <td>Sweet Cheeks</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 129971 entries, 0 to 129970
    Data columns (total 14 columns):
    Unnamed: 0               129971 non-null int64
    country                  129908 non-null object
    description              129971 non-null object
    designation              92506 non-null object
    points                   129971 non-null int64
    price                    120975 non-null float64
    province                 129908 non-null object
    region_1                 108724 non-null object
    region_2                 50511 non-null object
    taster_name              103727 non-null object
    taster_twitter_handle    98758 non-null object
    title                    129971 non-null object
    variety                  129970 non-null object
    winery                   129971 non-null object
    dtypes: float64(1), int64(2), object(11)
    memory usage: 13.9+ MB



```python
df.drop(['Unnamed: 0'], axis=1, inplace=True)
```


```python
df.isna().sum()
```




    country                     63
    description                  0
    designation              37465
    points                       0
    price                     8996
    province                    63
    region_1                 21247
    region_2                 79460
    taster_name              26244
    taster_twitter_handle    31213
    title                        0
    variety                      1
    winery                       0
    dtype: int64




```python
def fill_cols_na(df, column):
    
    """This function can be used to fill in columns with a literal 'N/A', if it is necessary
    
    Parameters:
    
    df - dataframe to pull columns from
    
    column - can be a single column or list of columns"""
        
    df2 = df.copy()
    
    df2[column] = df2[column].fillna('N/A')
    
    return df2
```


```python
df = fill_cols_na(df, ['country', 'designation', 'province', 'region_1', 'region_2', 'taster_name',
                      'taster_twitter_handle', 'variety'])
```


```python
pd.set_option('display.max_rows', 500)
```


```python
df['price'].value_counts()
```




    20.0      6940
    15.0      6066
    25.0      5805
    30.0      4951
    18.0      4883
    12.0      3934
    40.0      3872
    35.0      3801
    13.0      3549
    16.0      3547
    10.0      3439
    22.0      3357
    50.0      3334
    14.0      3215
    45.0      3135
    17.0      3053
    28.0      2942
    24.0      2826
    19.0      2816
    60.0      2277
    11.0      2058
    55.0      1981
    32.0      1963
    38.0      1728
    23.0      1715
    26.0      1706
    65.0      1614
    75.0      1403
    42.0      1403
    36.0      1392
    29.0      1387
    9.0       1339
    48.0      1309
    21.0      1232
    27.0      1193
    70.0      1100
    34.0      1069
    39.0       924
    8.0        892
    80.0       881
    33.0       668
    90.0       665
    85.0       655
    44.0       586
    100.0      585
    49.0       585
    37.0       527
    52.0       517
    7.0        433
    46.0       430
    58.0       413
    95.0       397
    54.0       384
    125.0      328
    43.0       311
    56.0       291
    31.0       276
    59.0       263
    120.0      262
    62.0       253
    150.0      239
    47.0       239
    68.0       222
    110.0      200
    69.0       195
    41.0       194
    53.0       187
    64.0       186
    72.0       178
    57.0       144
    130.0      141
    105.0      133
    79.0       128
    78.0       125
    6.0        120
    66.0       118
    115.0      114
    140.0      112
    135.0      110
    63.0        98
    200.0       94
    67.0        89
    99.0        84
    175.0       82
    51.0        79
    82.0        75
    89.0        70
    145.0       67
    74.0        65
    92.0        61
    160.0       60
    61.0        59
    73.0        53
    88.0        52
    77.0        52
    250.0       51
    98.0        48
    5.0         46
    86.0        45
    84.0        44
    225.0       41
    76.0        39
    96.0        37
    300.0       36
    165.0       36
    155.0       34
    170.0       34
    94.0        33
    87.0        32
    180.0       31
    93.0        30
    112.0       29
    103.0       28
    450.0       27
    97.0        27
    83.0        27
    108.0       27
    190.0       26
    195.0       26
    350.0       21
    210.0       21
    71.0        20
    107.0       19
    185.0       19
    102.0       18
    81.0        17
    149.0       17
    400.0       17
    260.0       17
    104.0       16
    106.0       16
    101.0       15
    240.0       15
    275.0       15
    500.0       14
    118.0       14
    109.0       14
    128.0       14
    111.0       13
    114.0       13
    235.0       13
    220.0       13
    113.0       13
    129.0       12
    290.0       12
    230.0       12
    169.0       12
    325.0       11
    116.0       11
    117.0       11
    132.0       11
    4.0         11
    91.0        10
    138.0       10
    119.0        8
    199.0        8
    330.0        8
    142.0        8
    139.0        8
    320.0        8
    127.0        8
    215.0        8
    122.0        8
    255.0        7
    124.0        7
    179.0        7
    126.0        7
    365.0        7
    163.0        6
    143.0        6
    460.0        6
    299.0        6
    440.0        6
    236.0        5
    550.0        5
    168.0        5
    800.0        5
    141.0        5
    154.0        5
    133.0        5
    280.0        5
    148.0        5
    159.0        5
    279.0        5
    249.0        5
    137.0        5
    375.0        5
    134.0        4
    775.0        4
    380.0        4
    600.0        4
    625.0        4
    245.0        4
    360.0        4
    131.0        4
    152.0        4
    147.0        4
    166.0        4
    146.0        4
    270.0        4
    227.0        4
    144.0        4
    164.0        3
    530.0        3
    305.0        3
    475.0        3
    295.0        3
    286.0        3
    595.0        3
    262.0        3
    430.0        3
    136.0        3
    123.0        3
    153.0        3
    495.0        3
    850.0        3
    158.0        3
    162.0        3
    312.0        3
    650.0        3
    237.0        3
    167.0        3
    1100.0       2
    1500.0       2
    243.0        2
    390.0        2
    156.0        2
    476.0        2
    121.0        2
    391.0        2
    580.0        2
    151.0        2
    194.0        2
    370.0        2
    359.0        2
    187.0        2
    1000.0       2
    310.0        2
    303.0        2
    171.0        2
    333.0        2
    520.0        2
    204.0        2
    398.0        2
    2000.0       2
    307.0        2
    196.0        2
    399.0        2
    510.0        2
    469.0        2
    193.0        2
    181.0        2
    224.0        2
    161.0        2
    184.0        2
    208.0        2
    314.0        2
    265.0        2
    182.0        2
    315.0        2
    219.0        2
    248.0        2
    770.0        2
    285.0        2
    174.0        2
    231.0        2
    2500.0       2
    292.0        2
    316.0        2
    214.0        2
    304.0        2
    188.0        2
    259.0        2
    685.0        2
    197.0        2
    455.0        2
    282.0        1
    328.0        1
    202.0        1
    698.0        1
    474.0        1
    257.0        1
    239.0        1
    468.0        1
    420.0        1
    412.0        1
    1300.0       1
    376.0        1
    525.0        1
    900.0        1
    176.0        1
    886.0        1
    790.0        1
    980.0        1
    207.0        1
    253.0        1
    540.0        1
    234.0        1
    172.0        1
    395.0        1
    222.0        1
    323.0        1
    351.0        1
    486.0        1
    258.0        1
    1200.0       1
    288.0        1
    367.0        1
    750.0        1
    425.0        1
    183.0        1
    415.0        1
    496.0        1
    357.0        1
    271.0        1
    306.0        1
    848.0        1
    780.0        1
    973.0        1
    617.0        1
    467.0        1
    252.0        1
    272.0        1
    767.0        1
    319.0        1
    177.0        1
    764.0        1
    191.0        1
    198.0        1
    410.0        1
    317.0        1
    226.0        1
    639.0        1
    630.0        1
    301.0        1
    757.0        1
    322.0        1
    385.0        1
    203.0        1
    672.0        1
    710.0        1
    2013.0       1
    209.0        1
    388.0        1
    268.0        1
    229.0        1
    281.0        1
    448.0        1
    238.0        1
    369.0        1
    428.0        1
    269.0        1
    276.0        1
    3300.0       1
    480.0        1
    212.0        1
    293.0        1
    675.0        1
    157.0        1
    273.0        1
    463.0        1
    545.0        1
    588.0        1
    206.0        1
    419.0        1
    426.0        1
    1125.0       1
    189.0        1
    499.0        1
    205.0        1
    451.0        1
    660.0        1
    355.0        1
    560.0        1
    228.0        1
    353.0        1
    335.0        1
    470.0        1
    242.0        1
    575.0        1
    574.0        1
    612.0        1
    445.0        1
    569.0        1
    932.0        1
    216.0        1
    247.0        1
    1900.0       1
    602.0        1
    820.0        1
    Name: price, dtype: int64




```python
df['price'].describe()
```




    count    120975.000000
    mean         35.363389
    std          41.022218
    min           4.000000
    25%          17.000000
    50%          25.000000
    75%          42.000000
    max        3300.000000
    Name: price, dtype: float64




```python
df['price'].median()
```




    25.0




```python
df['price'].mode()
```




    0    20.0
    dtype: float64




```python
df['price'].fillna(df['price'].median(), inplace=True)
```


```python
df.isna().sum()
```




    country                  0
    description              0
    designation              0
    points                   0
    price                    0
    province                 0
    region_1                 0
    region_2                 0
    taster_name              0
    taster_twitter_handle    0
    title                    0
    variety                  0
    winery                   0
    dtype: int64




```python
df['price'].hist(bins='auto')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fe7450bf390>




```python
import numpy as np
from scipy.stats import zscore
good_rows = np.abs(zscore(df['price'].values))<=3
df[good_rows]['price'].hist(bins='auto')
df=df[good_rows]
```


![png](output_17_0.png)



```python
cut_labels = [0, 1, 2, 3]
cut_bins = [0,40,80,120,160]
ax = df['price'].hist(bins='auto')
[ax.axvline(val) for val in cut_bins]
df['Price Category'] = pd.cut(df['price'], bins=cut_bins, labels=cut_labels)
```


![png](output_18_0.png)



```python
df['Price Category'].value_counts(normalize=True)
```




    0    0.766383
    1    0.193710
    2    0.030820
    3    0.009087
    Name: Price Category, dtype: float64




```python
df.isna().sum()
```




    country                  0
    description              0
    designation              0
    points                   0
    price                    0
    province                 0
    region_1                 0
    region_2                 0
    taster_name              0
    taster_twitter_handle    0
    title                    0
    variety                  0
    winery                   0
    Price Category           0
    dtype: int64



# Text Preprocessing


```python
import numpy as np
np.random.seed(0)
from gensim.models import Word2Vec
from nltk import word_tokenize
from nltk import FreqDist
from nltk.corpus import stopwords
import string
```


```python
corpus = df['description']
corpus[:10]
```




    0    Aromas include tropical fruit, broom, brimston...
    1    This is ripe and fruity, a wine that is smooth...
    2    Tart and snappy, the flavors of lime flesh and...
    3    Pineapple rind, lemon pith and orange blossom ...
    4    Much like the regular bottling from 2012, this...
    5    Blackberry and raspberry aromas show a typical...
    6    Here's a bright, informal red that opens with ...
    7    This dry and restrained wine offers spice in p...
    8    Savory dried thyme notes accent sunnier flavor...
    9    This has great depth of flavor with its fresh ...
    Name: description, dtype: object




```python
','.join(corpus)[:100]
```




    "Aromas include tropical fruit, broom, brimstone and dried herb. The palate isn't overly expressive, "




```python
freq = FreqDist(','.join(corpus))
freq.most_common(100)
```




    [(' ', 5057673),
     ('e', 2646377),
     ('a', 2172393),
     ('t', 2011884),
     ('i', 1972193),
     ('n', 1780800),
     ('r', 1741191),
     ('s', 1635001),
     ('o', 1534916),
     ('l', 1173055),
     ('h', 1137613),
     ('d', 1000737),
     ('c', 763747),
     ('f', 700384),
     ('u', 635160),
     (',', 563993),
     ('y', 561736),
     ('p', 546591),
     ('m', 469445),
     ('g', 456009),
     ('b', 437419),
     ('w', 436031),
     ('.', 351920),
     ('v', 258032),
     ('k', 221797),
     ('T', 114471),
     ('-', 75738),
     ("'", 58035),
     ('x', 55576),
     ('I', 51694),
     ('0', 47702),
     ('A', 44238),
     ('S', 42445),
     ('2', 41814),
     ('C', 40157),
     ('j', 32076),
     ('D', 31312),
     ('1', 27614),
     ('M', 26333),
     ('B', 24521),
     ('P', 23005),
     ('F', 22965),
     ('z', 19852),
     ('%', 19017),
     ('R', 17555),
     ('q', 15807),
     ('G', 13439),
     ('W', 12517),
     ('V', 12291),
     ('N', 11318),
     ('L', 10952),
     ('5', 10064),
     ('H', 8203),
     ('8', 8014),
     ('O', 7753),
     ('3', 6910),
     ('7', 6386),
     ('E', 6353),
     ('9', 6256),
     ('–', 6142),
     ('6', 5969),
     ('é', 5836),
     ('4', 5512),
     ('—', 4311),
     (')', 4283),
     ('(', 4275),
     (';', 2940),
     ('J', 2934),
     ('Z', 2907),
     ('Y', 2553),
     ('è', 2252),
     ('K', 1624),
     (':', 1415),
     ('U', 1400),
     ('ô', 965),
     ('/', 813),
     ('ü', 801),
     ('Q', 768),
     ('”', 697),
     ('“', 693),
     ('â', 595),
     ('?', 475),
     ('ã', 424),
     ('ñ', 377),
     ('$', 343),
     ('’', 318),
     ('û', 300),
     ('ä', 283),
     ('í', 140),
     ('!', 137),
     ('&', 135),
     ('ç', 131),
     ('X', 131),
     ('É', 73),
     ('à', 69),
     ('"', 54),
     ('á', 52),
     ('ö', 50),
     ('‘', 49),
     ('ê', 45)]




```python
tokens = word_tokenize(','.join(corpus))
tokens[:10]
```




    ['Aromas',
     'include',
     'tropical',
     'fruit',
     ',',
     'broom',
     ',',
     'brimstone',
     'and',
     'dried']




```python
len(tokens)
```




    6061563




```python
freq = FreqDist(tokens)
freq.most_common(100)
```




    [(',', 562769),
     ('and', 343503),
     ('.', 221767),
     ('of', 170907),
     ('the', 166105),
     ('a', 155975),
     ('with', 114656),
     ('is', 95971),
     ('wine', 76835),
     ('this', 71932),
     ('in', 59354),
     ('flavors', 57106),
     ('to', 54617),
     ('The', 52018),
     ("'s", 50731),
     ('fruit', 43171),
     ('It', 42989),
     ('on', 42685),
     ('it', 41389),
     ('This', 40696),
     ('that', 38806),
     ('palate', 37090),
     ('aromas', 35099),
     ('acidity', 30981),
     ('from', 29438),
     ('but', 29066),
     ('tannins', 27217),
     ('cherry', 26601),
     ('are', 25650),
     ('ripe', 24537),
     ('has', 24322),
     ('black', 23986),
     ('finish', 21876),
     ('A', 21645),
     ('for', 20441),
     ('by', 20387),
     ('Drink', 20008),
     ('%', 19017),
     ('notes', 17791),
     ('red', 17665),
     ('spice', 17638),
     ('as', 17046),
     ('nose', 16788),
     ('its', 16027),
     ('rich', 15693),
     ('an', 15570),
     ('oak', 15230),
     ('berry', 15089),
     ('fresh', 15060),
     ('dry', 13635),
     ('plum', 13588),
     ('fruits', 13038),
     ('blend', 12871),
     ('finish.', 12784),
     ('offers', 12474),
     ('apple', 12353),
     ('blackberry', 11976),
     ('white', 11888),
     ('soft', 11849),
     ('crisp', 11567),
     ('sweet', 11421),
     ('texture', 11387),
     ('through', 11051),
     ('citrus', 10875),
     ('shows', 10435),
     ('Cabernet', 10250),
     ('vanilla', 10117),
     ('well', 9906),
     ('dark', 9897),
     ('while', 9891),
     ('light', 9679),
     ('bright', 9651),
     ('more', 9405),
     ('at', 9391),
     ('pepper', 9159),
     ('full', 9040),
     ('juicy', 8968),
     ('fruity', 8957),
     ('raspberry', 8952),
     ('very', 8581),
     ('green', 8578),
     ('good', 8545),
     ('some', 8420),
     ('touch', 8395),
     ('firm', 8298),
     ('peach', 8205),
     ('lemon', 8099),
     ('now', 7878),
     ('will', 7714),
     ('character', 7695),
     ('chocolate', 7686),
     ('There', 7604),
     ('pear', 7553),
     ('dried', 7455),
     ('drink', 7356),
     ('or', 7326),
     ('Sauvignon', 7319),
     ('balanced', 7274),
     ('out', 7250),
     ('be', 7112)]




```python
stopwords_list = stopwords.words('english')
stopwords_list
```




    ['i',
     'me',
     'my',
     'myself',
     'we',
     'our',
     'ours',
     'ourselves',
     'you',
     "you're",
     "you've",
     "you'll",
     "you'd",
     'your',
     'yours',
     'yourself',
     'yourselves',
     'he',
     'him',
     'his',
     'himself',
     'she',
     "she's",
     'her',
     'hers',
     'herself',
     'it',
     "it's",
     'its',
     'itself',
     'they',
     'them',
     'their',
     'theirs',
     'themselves',
     'what',
     'which',
     'who',
     'whom',
     'this',
     'that',
     "that'll",
     'these',
     'those',
     'am',
     'is',
     'are',
     'was',
     'were',
     'be',
     'been',
     'being',
     'have',
     'has',
     'had',
     'having',
     'do',
     'does',
     'did',
     'doing',
     'a',
     'an',
     'the',
     'and',
     'but',
     'if',
     'or',
     'because',
     'as',
     'until',
     'while',
     'of',
     'at',
     'by',
     'for',
     'with',
     'about',
     'against',
     'between',
     'into',
     'through',
     'during',
     'before',
     'after',
     'above',
     'below',
     'to',
     'from',
     'up',
     'down',
     'in',
     'out',
     'on',
     'off',
     'over',
     'under',
     'again',
     'further',
     'then',
     'once',
     'here',
     'there',
     'when',
     'where',
     'why',
     'how',
     'all',
     'any',
     'both',
     'each',
     'few',
     'more',
     'most',
     'other',
     'some',
     'such',
     'no',
     'nor',
     'not',
     'only',
     'own',
     'same',
     'so',
     'than',
     'too',
     'very',
     's',
     't',
     'can',
     'will',
     'just',
     'don',
     "don't",
     'should',
     "should've",
     'now',
     'd',
     'll',
     'm',
     'o',
     're',
     've',
     'y',
     'ain',
     'aren',
     "aren't",
     'couldn',
     "couldn't",
     'didn',
     "didn't",
     'doesn',
     "doesn't",
     'hadn',
     "hadn't",
     'hasn',
     "hasn't",
     'haven',
     "haven't",
     'isn',
     "isn't",
     'ma',
     'mightn',
     "mightn't",
     'mustn',
     "mustn't",
     'needn',
     "needn't",
     'shan',
     "shan't",
     'shouldn',
     "shouldn't",
     'wasn',
     "wasn't",
     'weren',
     "weren't",
     'won',
     "won't",
     'wouldn',
     "wouldn't"]




```python
additional_punc = ['“','”','...','``',"''",'’',"'s"]
```


```python
stopwords_list+=string.punctuation
stopwords_list.extend(additional_punc)
stopwords_list
```




    ['i',
     'me',
     'my',
     'myself',
     'we',
     'our',
     'ours',
     'ourselves',
     'you',
     "you're",
     "you've",
     "you'll",
     "you'd",
     'your',
     'yours',
     'yourself',
     'yourselves',
     'he',
     'him',
     'his',
     'himself',
     'she',
     "she's",
     'her',
     'hers',
     'herself',
     'it',
     "it's",
     'its',
     'itself',
     'they',
     'them',
     'their',
     'theirs',
     'themselves',
     'what',
     'which',
     'who',
     'whom',
     'this',
     'that',
     "that'll",
     'these',
     'those',
     'am',
     'is',
     'are',
     'was',
     'were',
     'be',
     'been',
     'being',
     'have',
     'has',
     'had',
     'having',
     'do',
     'does',
     'did',
     'doing',
     'a',
     'an',
     'the',
     'and',
     'but',
     'if',
     'or',
     'because',
     'as',
     'until',
     'while',
     'of',
     'at',
     'by',
     'for',
     'with',
     'about',
     'against',
     'between',
     'into',
     'through',
     'during',
     'before',
     'after',
     'above',
     'below',
     'to',
     'from',
     'up',
     'down',
     'in',
     'out',
     'on',
     'off',
     'over',
     'under',
     'again',
     'further',
     'then',
     'once',
     'here',
     'there',
     'when',
     'where',
     'why',
     'how',
     'all',
     'any',
     'both',
     'each',
     'few',
     'more',
     'most',
     'other',
     'some',
     'such',
     'no',
     'nor',
     'not',
     'only',
     'own',
     'same',
     'so',
     'than',
     'too',
     'very',
     's',
     't',
     'can',
     'will',
     'just',
     'don',
     "don't",
     'should',
     "should've",
     'now',
     'd',
     'll',
     'm',
     'o',
     're',
     've',
     'y',
     'ain',
     'aren',
     "aren't",
     'couldn',
     "couldn't",
     'didn',
     "didn't",
     'doesn',
     "doesn't",
     'hadn',
     "hadn't",
     'hasn',
     "hasn't",
     'haven',
     "haven't",
     'isn',
     "isn't",
     'ma',
     'mightn',
     "mightn't",
     'mustn',
     "mustn't",
     'needn',
     "needn't",
     'shan',
     "shan't",
     'shouldn',
     "shouldn't",
     'wasn',
     "wasn't",
     'weren',
     "weren't",
     'won',
     "won't",
     'wouldn',
     "wouldn't",
     '!',
     '"',
     '#',
     '$',
     '%',
     '&',
     "'",
     '(',
     ')',
     '*',
     '+',
     ',',
     '-',
     '.',
     '/',
     ':',
     ';',
     '<',
     '=',
     '>',
     '?',
     '@',
     '[',
     '\\',
     ']',
     '^',
     '_',
     '`',
     '{',
     '|',
     '}',
     '~',
     '“',
     '”',
     '...',
     '``',
     "''",
     '’',
     "'s"]




```python
stopped_tokens = [word.lower() for word in tokens if word.lower() not in stopwords_list]
stopped_tokens
```




    ['aromas',
     'include',
     'tropical',
     'fruit',
     'broom',
     'brimstone',
     'dried',
     'herb',
     'palate',
     "n't",
     'overly',
     'expressive',
     'offering',
     'unripened',
     'apple',
     'citrus',
     'dried',
     'sage',
     'alongside',
     'brisk',
     'acidity.',
     'ripe',
     'fruity',
     'wine',
     'smooth',
     'still',
     'structured',
     'firm',
     'tannins',
     'filled',
     'juicy',
     'red',
     'berry',
     'fruits',
     'freshened',
     'acidity',
     'already',
     'drinkable',
     'although',
     'certainly',
     'better',
     '2016.',
     'tart',
     'snappy',
     'flavors',
     'lime',
     'flesh',
     'rind',
     'dominate',
     'green',
     'pineapple',
     'pokes',
     'crisp',
     'acidity',
     'underscoring',
     'flavors',
     'wine',
     'stainless-steel',
     'fermented.',
     'pineapple',
     'rind',
     'lemon',
     'pith',
     'orange',
     'blossom',
     'start',
     'aromas',
     'palate',
     'bit',
     'opulent',
     'notes',
     'honey-drizzled',
     'guava',
     'mango',
     'giving',
     'way',
     'slightly',
     'astringent',
     'semidry',
     'finish.',
     'much',
     'like',
     'regular',
     'bottling',
     '2012',
     'comes',
     'across',
     'rather',
     'rough',
     'tannic',
     'rustic',
     'earthy',
     'herbal',
     'characteristics',
     'nonetheless',
     'think',
     'pleasantly',
     'unfussy',
     'country',
     'wine',
     'good',
     'companion',
     'hearty',
     'winter',
     'stew.',
     'blackberry',
     'raspberry',
     'aromas',
     'show',
     'typical',
     'navarran',
     'whiff',
     'green',
     'herbs',
     'case',
     'horseradish',
     'mouth',
     'fairly',
     'full',
     'bodied',
     'tomatoey',
     'acidity',
     'spicy',
     'herbal',
     'flavors',
     'complement',
     'dark',
     'plum',
     'fruit',
     'finish',
     'fresh',
     'grabby.',
     'bright',
     'informal',
     'red',
     'opens',
     'aromas',
     'candied',
     'berry',
     'white',
     'pepper',
     'savory',
     'herb',
     'carry',
     'palate',
     'balanced',
     'fresh',
     'acidity',
     'soft',
     'tannins.',
     'dry',
     'restrained',
     'wine',
     'offers',
     'spice',
     'profusion',
     'balanced',
     'acidity',
     'firm',
     'texture',
     'much',
     'food.',
     'savory',
     'dried',
     'thyme',
     'notes',
     'accent',
     'sunnier',
     'flavors',
     'preserved',
     'peach',
     'brisk',
     'off-dry',
     'wine',
     'fruity',
     'fresh',
     'elegant',
     'sprightly',
     'footprint.',
     'great',
     'depth',
     'flavor',
     'fresh',
     'apple',
     'pear',
     'fruits',
     'touch',
     'spice',
     'dry',
     'balanced',
     'acidity',
     'crisp',
     'texture',
     'drink',
     'now.',
     'soft',
     'supple',
     'plum',
     'envelopes',
     'oaky',
     'structure',
     'cabernet',
     'supported',
     '15',
     'merlot',
     'coffee',
     'chocolate',
     'complete',
     'picture',
     'finishing',
     'strong',
     'end',
     'resulting',
     'value-priced',
     'wine',
     'attractive',
     'flavor',
     'immediate',
     'accessibility.',
     'dry',
     'wine',
     'spicy',
     'tight',
     'taut',
     'texture',
     'strongly',
     'mineral',
     'character',
     'layered',
     'citrus',
     'well',
     'pepper',
     'food',
     'wine',
     'almost',
     'crisp',
     'aftertaste.',
     'slightly',
     'reduced',
     'wine',
     'offers',
     'chalky',
     'tannic',
     'backbone',
     'otherwise',
     'juicy',
     'explosion',
     'rich',
     'black',
     'cherry',
     'whole',
     'accented',
     'throughout',
     'firm',
     'oak',
     'cigar',
     'box.',
     'dominated',
     'oak',
     'oak-driven',
     'aromas',
     'include',
     'roasted',
     'coffee',
     'bean',
     'espresso',
     'coconut',
     'vanilla',
     'carry',
     'palate',
     'together',
     'plum',
     'chocolate',
     'astringent',
     'drying',
     'tannins',
     'give',
     'rather',
     'abrupt',
     'finish.',
     'building',
     '150',
     'years',
     'six',
     'generations',
     'winemaking',
     'tradition',
     'winery',
     'trends',
     'toward',
     'leaner',
     'style',
     'classic',
     'california',
     'buttercream',
     'aroma',
     'cut',
     'tart',
     'green',
     'apple',
     'good',
     'everyday',
     'sipping',
     'wine',
     'flavors',
     'range',
     'pear',
     'barely',
     'ripe',
     'pineapple',
     'prove',
     'approachable',
     'distinctive.',
     'zesty',
     'orange',
     'peels',
     'apple',
     'notes',
     'abound',
     'sprightly',
     'mineral-toned',
     'riesling',
     'dry',
     'palate',
     'yet',
     'racy',
     'lean',
     'refreshing',
     'easy',
     'quaffer',
     'wide',
     'appeal.',
     'baked',
     'plum',
     'molasses',
     'balsamic',
     'vinegar',
     'cheesy',
     'oak',
     'aromas',
     'feed',
     'palate',
     'braced',
     'bolt',
     'acidity',
     'compact',
     'set',
     'saucy',
     'red-berry',
     'plum',
     'flavors',
     'features',
     'tobacco',
     'peppery',
     'accents',
     'finish',
     'mildly',
     'green',
     'flavor',
     'respectable',
     'weight',
     'balance.',
     'raw',
     'black-cherry',
     'aromas',
     'direct',
     'simple',
     'good',
     'juicy',
     'feel',
     'thickens',
     'time',
     'oak',
     'character',
     'extract',
     'becoming',
     'apparent',
     'flavor',
     'profile',
     'driven',
     'dark-berry',
     'fruits',
     'smoldering',
     'oak',
     'finishes',
     'meaty',
     'hot.',
     'desiccated',
     'blackberry',
     'leather',
     'charred',
     'wood',
     'mint',
     'aromas',
     'carry',
     'nose',
     'full-bodied',
     'tannic',
     'heavily',
     'oaked',
     'tinto',
     'fino',
     'flavors',
     'clove',
     'woodspice',
     'sit',
     'top',
     'blackberry',
     'fruit',
     'hickory',
     'forceful',
     'oak-based',
     'aromas',
     'rise',
     'dominate',
     'finish.',
     'red',
     'fruit',
     'aromas',
     'pervade',
     'nose',
     'cigar',
     'box',
     'menthol',
     'notes',
     'riding',
     'back',
     'palate',
     'slightly',
     'restrained',
     'entry',
     'opens',
     'riper',
     'notes',
     'cherry',
     'plum',
     'specked',
     'crushed',
     'pepper',
     'blend',
     'merlot',
     'cabernet',
     'sauvignon',
     'cabernet',
     'franc',
     'approachable',
     'ready',
     'enjoyed.',
     'ripe',
     'aromas',
     'dark',
     'berries',
     'mingle',
     'ample',
     'notes',
     'black',
     'pepper',
     'toasted',
     'vanilla',
     'dusty',
     'tobacco',
     'palate',
     'oak-driven',
     'nature',
     'notes',
     'tart',
     'red',
     'currant',
     'shine',
     'offering',
     'bit',
     'levity.',
     'sleek',
     'mix',
     'tart',
     'berry',
     'stem',
     'herb',
     'along',
     'hint',
     'oak',
     'chocolate',
     'fair',
     'value',
     'widely',
     'available',
     'drink-now',
     'oregon',
     'pinot',
     'wine',
     'oak-aged',
     'six',
     'months',
     'whether',
     'neutral',
     're-staved',
     'indicated.',
     'delicate',
     'aromas',
     'recall',
     'white',
     'flower',
     'citrus',
     'palate',
     'offers',
     'passion',
     'fruit',
     'lime',
     'white',
     'peach',
     'hint',
     'mineral',
     'alongside',
     'bright',
     'acidity.',
     'wine',
     'geneseo',
     'district',
     'offers',
     'aromas',
     'sour',
     'plums',
     'enough',
     'cigar',
     'box',
     'tempt',
     'nose',
     'flavors',
     'bit',
     'flat',
     'first',
     'acidity',
     'tension',
     'sour',
     'cherries',
     'emerges',
     'midpalate',
     'bolstered',
     'black',
     'licorice.',
     'aromas',
     'prune',
     'blackcurrant',
     'toast',
     'oak',
     'carry',
     'extracted',
     'palate',
     'along',
     'flavors',
     'black',
     'cherry',
     'roasted',
     'coffee',
     'beans',
     'firm',
     'drying',
     'tannins',
     'provide',
     'framework.',
     'oak',
     'earth',
     'intermingle',
     'around',
     'robust',
     'aromas',
     'wet',
     'forest',
     'floor',
     'vineyard-designated',
     'pinot',
     'hails',
     'high-elevation',
     'site',
     'small',
     'production',
     'offers',
     'intense',
     'full-bodied',
     'raspberry',
     'blackberry',
     'steeped',
     'smoky',
     'spice',
     'smooth',
     'texture.',
     'pretty',
     'aromas',
     'yellow',
     'flower',
     'stone',
     'fruit',
     'lead',
     'nose',
     'bright',
     'palate',
     'offers',
     'yellow',
     'apple',
     'apricot',
     'vanilla',
     'delicate',
     'notes',
     'lightly',
     'toasted',
     'oak',
     'alongside',
     'crisp',
     'acidity.',
     'aromas',
     'recall',
     'ripe',
     'dark',
     'berry',
     'toast',
     'whiff',
     'cake',
     'spice',
     'soft',
     'informal',
     'palate',
     'offers',
     'sour',
     'cherry',
     'vanilla',
     'hint',
     'espresso',
     'alongside',
     'round',
     'tannins',
     'drink',
     'soon.',
     'aromas',
     'suggest',
     'mature',
     'berry',
     'scorched',
     'earth',
     'animal',
     'toast',
     'anise',
     'palate',
     'offers',
     'ripe',
     'black',
     'berry',
     'oak',
     'espresso',
     'cocoa',
     'vanilla',
     'alongside',
     'dusty',
     'tannins.',
     'clarksburg',
     'becoming',
     'chenin',
     'blanc',
     'california',
     'bottling',
     'using',
     'fruit',
     'sourced',
     'several',
     'vineyards',
     'area',
     'balanced',
     'trace',
     'sweetness',
     'background',
     '1',
     'residual',
     'sugar',
     'crisp',
     'straightforward',
     'blessed',
     'notes',
     'pear',
     'lime',
     'drink',
     'cold.',
     'red',
     'cherry',
     'fruit',
     'comes',
     'laced',
     'light',
     'tannins',
     'giving',
     'bright',
     'wine',
     'open',
     'juicy',
     'character.',
     'merlot',
     'nero',
     "d'avola",
     'form',
     'base',
     'easy',
     'red',
     'wine',
     'would',
     'pair',
     'fettuccine',
     'meat',
     'sauce',
     'pork',
     'roast',
     'quality',
     'fruit',
     'clean',
     'bright',
     'sharp.',
     'part',
     'extended',
     'calanìca',
     'series',
     'grillo-viognier',
     'blend',
     'shows',
     'aromas',
     'honeysuckle',
     'jasmine',
     'backed',
     'touches',
     'cut',
     'grass',
     'wild',
     'sage',
     'mouth',
     'shows',
     'ripe',
     'yellow-fruit',
     'flavors.',
     'rustic',
     'dry',
     'flavors',
     'berries',
     'currants',
     'licorice',
     'spices',
     'made',
     'cabernet',
     'franc',
     'cabernet',
     'sauvignon.',
     'shows',
     'tart',
     'green',
     'gooseberry',
     'flavor',
     'similar',
     'new',
     'zealand',
     'sauvignon',
     'blanc',
     'notes',
     'include',
     'tropical',
     'fruit',
     'orange',
     'honey',
     'unoaked',
     'splash',
     'muscat',
     'commendable',
     'dryness',
     'acidity.',
     'many',
     'erath',
     '2010',
     'vineyard',
     'designates',
     'strongly',
     'herbal',
     'notes',
     'leaf',
     'herb',
     'create',
     'somewhat',
     'unripe',
     'flavor',
     'impressions',
     'touch',
     'bitterness',
     'finish',
     'fruit',
     'passes',
     'ripeness',
     'sweet',
     'tomatoes.',
     'white',
     'flower',
     'lychee',
     'apple',
     'aromas',
     'carry',
     'mellow',
     'bouquet',
     'chunky-feeling',
     'palate',
     'bears',
     'powdery',
     'sweet',
     'flavors',
     'peach',
     'melon',
     'mixed',
     'greener',
     'notes',
     'grass',
     'lime',
     '80',
     'viognier',
     'component',
     'typical',
     'warm',
     'climate',
     'plump',
     'oily',
     'short',
     'finish',
     'chardonnay',
     'fills',
     'blend.',
     'concentrated',
     'cabernet',
     'offers',
     'aromas',
     'cured',
     'meat',
     'dried',
     'fruit',
     'rosemary',
     'barbecue',
     'spice',
     'teriyaki',
     'sauce',
     'flavors',
     'give',
     'wine',
     'bold',
     'chewy',
     'feel.',
     'inky',
     'color',
     'wine',
     'plump',
     'aromas',
     'ripe',
     'fruit',
     'blackberry',
     'jam',
     'rum',
     'cake',
     'palate',
     'soft',
     'smooth.',
     'part',
     'natural',
     'wine',
     'movement',
     'wine',
     'made',
     'organic',
     'grapes',
     'label',
     'printed',
     'vegetable',
     'ink',
     'recycled',
     'paper',
     'quality',
     'fruit',
     'nice',
     'juicy',
     'palate',
     'bright',
     'berry',
     'flavor',
     'finish.',
     'catarratto',
     'one',
     'sicily',
     'widely',
     'farmed',
     'white',
     'grape',
     'varieties',
     'expression',
     'shows',
     'mineral',
     'note',
     'backed',
     'citrus',
     'almond',
     'blossom',
     'touches.',
     'stiff',
     'tannic',
     'wine',
     'slowly',
     'opens',
     'brings',
     'brambly',
     'berry',
     'flavors',
     'play',
     'along',
     'notes',
     'earthy',
     'herbs',
     'touch',
     'bitterness',
     'tannins.',
     'festive',
     'wine',
     'soft',
     'ripe',
     'fruit',
     'acidity',
     'plus',
     'red',
     'berry',
     'flavor.',
     'clean',
     'brisk',
     'mouthfeel',
     'gives',
     'slightly',
     'oaked',
     'sauvignon',
     'blanc',
     'instant',
     'likeability',
     'dry',
     'rich',
     'streak',
     'honey',
     'sweetens',
     'citrus',
     'pear',
     'tropical',
     'fruit',
     'flavors',
     'pair',
     'asian',
     'fare',
     'ham',
     'green',
     'salad',
     'grapefruit',
     'sections.',
     'berry',
     'aroma',
     'comes',
     'cola',
     'herb',
     'notes',
     'palate',
     'tangy',
     'racy',
     'delivers',
     'raspberry',
     'plum',
     'flavors',
     'modest',
     'finish.',
     'right',
     'starting',
     'blocks',
     'oaky',
     'wine',
     'dripping',
     'caramel',
     'vanilla',
     'notes',
     'texture',
     'midpalate',
     'finessed',
     'graceful',
     'drying',
     'tannins',
     'latch',
     'onto',
     'oak-driven',
     'finish',
     'eccentric',
     'blend',
     '50',
     'tannat',
     '35',
     'petit',
     'verdot',
     '15',
     'pinotage.',
     'spicy',
     'fresh',
     'clean',
     'would',
     ...]




```python
len(stopped_tokens)
```




    3213762




```python
freq = FreqDist(stopped_tokens)
freq.most_common(100)
```




    [('wine', 77008),
     ('flavors', 59555),
     ('fruit', 43391),
     ('aromas', 39242),
     ('palate', 37094),
     ('acidity', 31404),
     ('tannins', 27567),
     ('drink', 27364),
     ('cherry', 26978),
     ('ripe', 26578),
     ('black', 24934),
     ('finish', 21879),
     ('red', 18555),
     ('notes', 18256),
     ('spice', 17922),
     ('rich', 16896),
     ('nose', 16801),
     ('fresh', 16593),
     ('oak', 15655),
     ('berry', 15282),
     ('dry', 15010),
     ('plum', 13935),
     ('soft', 13290),
     ('fruits', 13040),
     ('blend', 12888),
     ('finish.', 12784),
     ('apple', 12672),
     ('offers', 12578),
     ('crisp', 12577),
     ('blackberry', 12455),
     ('white', 12177),
     ('sweet', 12036),
     ('texture', 11405),
     ('shows', 11383),
     ('light', 11267),
     ('citrus', 11193),
     ('dark', 11094),
     ('bright', 10793),
     ('vanilla', 10361),
     ('cabernet', 10250),
     ('well', 10094),
     ('full', 9959),
     ('juicy', 9599),
     ('pepper', 9496),
     ('fruity', 9329),
     ('good', 9312),
     ('raspberry', 9180),
     ('firm', 8952),
     ('green', 8932),
     ('peach', 8403),
     ('touch', 8396),
     ('lemon', 8381),
     ('chocolate', 7780),
     ('dried', 7759),
     ('character', 7696),
     ('pear', 7695),
     ('balanced', 7580),
     ('sauvignon', 7319),
     ('spicy', 7049),
     ('structure', 7006),
     ('now.', 6938),
     ('smooth', 6873),
     ('pinot', 6669),
     ('made', 6363),
     ('tannic', 6180),
     ('also', 6166),
     ('herb', 6153),
     ('concentrated', 6125),
     ('herbal', 6093),
     ('tart', 6075),
     ('like', 6018),
     ('hint', 5935),
     ('wood', 5865),
     ('bit', 5787),
     ('licorice', 5773),
     ('mineral', 5770),
     ('fine', 5755),
     ('still', 5666),
     ('give', 5649),
     ('creamy', 5577),
     ('merlot', 5555),
     ('currant', 5506),
     ('long', 5505),
     ('note', 5499),
     ('opens', 5484),
     ('flavor', 5458),
     ('mouth', 5415),
     ('toast', 5340),
     ('orange', 5326),
     ('alongside', 5317),
     ('along', 5286),
     ('clean', 5266),
     ('dense', 5213),
     ('lead', 5196),
     ('full-bodied', 5130),
     ('savory', 5120),
     ('earthy', 5109),
     ('syrah', 5107),
     ('leather', 5078),
     ('age', 5072)]



# Neural Network


```python
target = df['Price Category']
```


```python
total_vocabulary = np.array((stopped_tokens))
```


```python
len(total_vocabulary)
print('There are {} unique tokens in the dataset.'.format(len(total_vocabulary)))
```

    There are 3213762 unique tokens in the dataset.



```python
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, Dense, LSTM, Embedding
from keras.layers import Dropout, Activation, Bidirectional, GlobalMaxPool1D
from keras.models import Sequential
from keras import initializers, regularizers, constraints, optimizers, layers
from keras.preprocessing import text, sequence
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
```

    Using TensorFlow backend.
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:517: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint8 = np.dtype([("qint8", np.int8, 1)])
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:518: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint8 = np.dtype([("quint8", np.uint8, 1)])
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:519: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint16 = np.dtype([("qint16", np.int16, 1)])
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:520: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint16 = np.dtype([("quint16", np.uint16, 1)])
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:521: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint32 = np.dtype([("qint32", np.int32, 1)])
    /Users/acusiobivona/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:526: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      np_resource = np.dtype([("resource", np.ubyte, 1)])



```python
y = to_categorical(target).copy()
X = total_vocabulary.copy()
```


```python
np.shape(X)
```




    (3213762,)




```python
np.shape(y)
```




    (128749, 4)




```python
X_train,X_test,y_train,y_test = train_test_split(X,y,stratify=y)
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-62-46ba46ac4c73> in <module>
    ----> 1 X_train,X_test,y_train,y_test = train_test_split(X,y,stratify=y)
    

    ~/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/sklearn/model_selection/_split.py in train_test_split(*arrays, **options)
       2116         raise TypeError("Invalid parameters passed: %s" % str(options))
       2117 
    -> 2118     arrays = indexable(*arrays)
       2119 
       2120     n_samples = _num_samples(arrays[0])


    ~/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/sklearn/utils/validation.py in indexable(*iterables)
        246     """
        247     result = [_make_indexable(X) for X in iterables]
    --> 248     check_consistent_length(*result)
        249     return result
        250 


    ~/opt/anaconda3/envs/learn-env/lib/python3.6/site-packages/sklearn/utils/validation.py in check_consistent_length(*arrays)
        210     if len(uniques) > 1:
        211         raise ValueError("Found input variables with inconsistent numbers of"
    --> 212                          " samples: %r" % [int(l) for l in lengths])
        213 
        214 


    ValueError: Found input variables with inconsistent numbers of samples: [3213762, 128749]



```python
X_train
```


```python
y_train
```


```python
y_test
```


```python
tokenizer = text.Tokenizer(num_words=20000)
tokenizer.fit_on_texts(X_train)
X_train_seq = tokenizer.texts_to_sequences(X_train)
X_tr = sequence.pad_sequences(X_train_seq, maxlen=100)
X_test_seq = tokenizer.texts_to_sequences(X_test)
X_te = sequence.pad_sequences(X_test_seq, maxlen=100)
```


```python
embedding_size = 128
model = Sequential()
model.add(Embedding(20000, embedding_size)) #input_length=100?
model.add(LSTM(25, return_sequences=True))
model.add(GlobalMaxPool1D())
model.add(Dropout(0.5))
model.add(Dense(50, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(5, activation='sigmoid'))

model.compile(loss='categorical_crossentropy', 
              optimizer='adam', 
              metrics=['accuracy'])

model.summary()
```


```python
model_2 = model.fit(X_tr, y_train, epochs=3, batch_size=128, validation_split=0.3)
```


```python
y_hat_test = model.predict(X_te)
#y_hat_test = model.predict_classes(X_te)
y_hat_test
```


```python
y_hat_test = y_hat_test.argmax(axis=1)#.shape)
y_hat_test
```


```python
def plot_confusion_matrix(conf_matrix, classes = None, normalize=True,
                          title='Confusion Matrix', cmap="Blues",
                          print_raw_matrix=False,
                          fig_size=(4,4)):
    """Check if Normalization Option is Set to True. 
    If so, normalize the raw confusion matrix before visualizing
    #Other code should be equivalent to your previous function.
    Note: Taken from bs_ds and modified
    - Can pass a tuple of (y_true,y_pred) instead of conf matrix.
    """
    import itertools
    import numpy as np
    import matplotlib.pyplot as plt
    import sklearn.metrics as metrics
    
    ## make confusion matrix if given tuple of y_true,y_pred
    if isinstance(conf_matrix, tuple):
        y_true = conf_matrix[0].copy()
        y_pred = conf_matrix[1].copy()
        
        if y_true.ndim>1:
            y_true = y_true.argmax(axis=1)
        if y_pred.ndim>1:
            y_pred = y_pred.argmax(axis=1)
            
            
        cm = metrics.confusion_matrix(y_true,y_pred)
    else:
        cm = conf_matrix
        
    ## Generate integer labels for classes
    if classes is None:
        classes = list(range(len(cm)))  
        
    ## Normalize data
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt='.2f'
    else:
        fmt= 'd'
        
        
    fontDict = {
        'title':{
            'fontsize':16,
            'fontweight':'semibold',
            'ha':'center',
            },
        'xlabel':{
            'fontsize':14,
            'fontweight':'normal',
            },
        'ylabel':{
            'fontsize':14,
            'fontweight':'normal',
            },
        'xtick_labels':{
            'fontsize':10,
            'fontweight':'normal',
    #             'rotation':45,
            'ha':'right',
            },
        'ytick_labels':{
            'fontsize':10,
            'fontweight':'normal',
            'rotation':0,
            'ha':'right',
            },
        'data_labels':{
            'ha':'center',
            'fontweight':'semibold',

        }
    }

    # Create plot
    fig,ax = plt.subplots(figsize=fig_size)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title,**fontDict['title'])
    plt.colorbar()

    tick_marks = classes#np.arange(len(classes))

    plt.xticks(tick_marks, classes, **fontDict['xtick_labels'])
    plt.yticks(tick_marks, classes,**fontDict['ytick_labels'])

    # Determine threshold for b/w text
    thresh = cm.max() / 2.

    # fig,ax = plt.subplots()
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 color='darkgray',**fontDict['data_labels']) #color="white" if cm[i, j] > thresh else "black"

    plt.tight_layout()
    plt.ylabel('True label',**fontDict['ylabel'])
    plt.xlabel('Predicted label',**fontDict['xlabel'])

    if print_raw_matrix:
        print_title = 'Raw Confusion Matrix Counts:'
        print('\n',print_title)
        print(conf_matrix)


    fig = plt.gcf()
    return fig



def plot_keras_history(history,figsize_1=(6,4),
    figsize_2=(8,6)):
    """Plots keras history and returns fig"""
    
    ## Make a df from history
    if isinstance(history,dict)==False:
        history=history.history
    plot_df = pd.DataFrame(history)
    plot_df['Epoch'] = range(1,len(plot_df)+1)
    plot_df.set_index('Epoch',inplace=True)
    ## Get cols for acc vs loss
    acc_cols = list(filter(lambda x: 'acc' in x, plot_df.columns))
    loss_cols = list(filter(lambda x: 'loss' in x, plot_df.columns))   
    
    ## Set figsizes based on number of keys
    if len(acc_cols)>1:
        figsize=figsize_2
    else:
        figsize=figsize_1

    ## Make figure and axes
    fig,ax = plt.subplots(nrows=2,figsize=figsize,sharex=True)
    
    ## Plot Accuracy cols in plot 1
    plot_df[acc_cols].plot(ax=ax[0])
    ax[0].set(ylabel='Accuracy')
    ax[0].set_title('Training Results')

    ## Plot loss cols in plot 2
    plot_df[loss_cols].plot(ax=ax[1])
    ax[1].set(ylabel='Loss')
    ax[1].set_xlabel('Epoch #')


#     ## Change xaxis locators 
#     [a.xaxis.set_major_locator(mpl.ticker.MaxNLocator(len(plot_df),integer=True)) for a in ax]
#     [a.set_xlim((1,len(plot_df)+1)) for a in ax]
    plt.tight_layout()
    
    return fig
```


```python
def evaluate_model(y_true, y_pred,history=None):
    """Evaluates neural network using sklearn metrics"""
    from sklearn import metrics
    if y_true.ndim>1:
        y_true = y_true.argmax(axis=1)
    if y_pred.ndim>1:
        y_pred = y_pred.argmax(axis=1)   
#     try:    
    if history is not None:
        plot_keras_history(history)
        plt.show()
#     except:
#         pass
    
    num_dashes=20
    print('\n')
    print('---'*num_dashes)
    print('\tCLASSIFICATION REPORT:')
    print('---'*num_dashes)
    try:
        print(metrics.classification_report(y_true,y_pred))
        
        fig = plot_confusion_matrix((y_true,y_pred))
        plt.show()
    except Exception as e:
        print(f"[!] Error during model evaluation:\n\t{e}")


```


```python
evaluate_model(y_test, y_hat_test, model_2)
#Big divergence is bad
```


```python
#Separate data according to class
```


```python
wordcloud = WordCloud(stopwords=None,collocations=False)
wordcloud.generate(','.join(stopped_tokens))
plt.figure(figsize = (12, 12), facecolor = None) 
plt.imshow(wordcloud) 
plt.axis('off')
```


```python
bigram_measures = nltk.collocations.BigramAssocMeasures()
word_finder = nltk.BigramCollocationFinder.from_words(stopped_tokens)

words_scored = word_finder.score_ngrams(bigram_measures.raw_freq)
top_words = pd.DataFrame.from_records(words_scored,columns=['Words','Frequency']).head(20)
top_words
```


```python
bigram_measures = nltk.collocations.BigramAssocMeasures()

word_pmi_finder = nltk.BigramCollocationFinder.from_words(stopped_vocabulary)
word_pmi_finder.apply_freq_filter(5)

word_pmi_scored = word_pmi_finder.score_ngrams(bigram_measures.pmi)
pd.DataFrame.from_records(word_pmi_scored,columns=['Words','PMI']).head(20)
```


```python

```
